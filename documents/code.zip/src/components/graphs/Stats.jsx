import React from 'react'

const statsStyle = {
    display:'flex',
    flexDirection: 'column',
    height: '100%',
    width:'100%'
}
class Stats extends React.Component{
    constructor(props){
        super(props)
    }

    render() {
        return(
            <div style={{statsStyle}}>

            </div>
        )
    }
}

export default Stats