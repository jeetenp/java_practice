//theme settings

const backgroundColor = '#212124'
const boxBackgroundColor = '#212124'

export default {
    backgroundColor,
    boxBackgroundColor,
}