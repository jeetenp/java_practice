Integrate the project with redux
