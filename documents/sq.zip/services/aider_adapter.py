
class AiderAdapter:
    def __init__(self, repo_path):
        self.repo_path = repo_path

    def fix_issue(self, issue):
        language = issue.get("language", "").lower()
        rule = issue.get("rule")
        message = issue.get("message")
        snippet = issue.get("code", "<code snippet placeholder>")

        prompt = self._build_prompt(issue, snippet, language)
        print(f"Applying fix for issue {issue['id']} using rule {rule} in {language}")
        print("Prompt:\n", prompt)

        # Call aider/LLM API with the prompt
        patch = self.call_llm_api(prompt)
        if patch:
            self.apply_patch_to_repo(patch)
        else:
            print("No patch returned from LLM API.")

    def call_llm_api(self, prompt):
        """
        Call the aider/LLM API with the prompt and return the patch.
        This is a placeholder implementation. Replace with actual API call.
        """
        import requests
        # Example: Replace with your actual aider/LLM endpoint and API key
        AIDER_API_URL = "http://localhost:5000/generate_patch"
        API_KEY = "your_api_key_here"
        try:
            response = requests.post(AIDER_API_URL, json={"prompt": prompt}, headers={"Authorization": f"Bearer {API_KEY}"})
            response.raise_for_status()
            return response.json().get("patch")
        except Exception as e:
            print(f"Error calling LLM API: {e}")
            return None

    def apply_patch_to_repo(self, patch):
        """
        Apply the patch to the repo at self.repo_path.
        This is a placeholder implementation. Replace with actual patch application logic.
        """
        import subprocess
        patch_file = f"{self.repo_path}/llm_patch.diff"
        with open(patch_file, "w") as f:
            f.write(patch)
        try:
            subprocess.run(["git", "apply", patch_file], cwd=self.repo_path, check=True)
            print("Patch applied successfully.")
        except subprocess.CalledProcessError as e:
            print(f"Failed to apply patch: {e}")

    def _build_prompt(self, issue, snippet, language):
        rule = issue.get("rule", "")
        message = issue.get("message", "")

        if language == "java":
            if rule.startswith("java:S") or "naming" in message.lower():
                return f"""You are reviewing Java code flagged by SonarQube.\nRule: {rule}\nMessage: {message}\nContext: {snippet}\n\nFix the issue while preserving functionality and adhering to Java best practices. Explain changes briefly in comments."""

            if "bug" in message.lower():
                return f"""You are reviewing a potential bug in Java code from SonarQube.\nRule: {rule}\nMessage: {message}\nCode: {snippet}\n\nFix the bug safely. Ensure functional correctness and add tests if needed. Explain the reason for the fix in comments."""

            if "vulnerability" in message.lower() or rule.startswith("security:"):
                return f"""You are a security expert. SonarQube flagged a vulnerability in Java code.\nRule: {rule}\nMessage: {message}\nCode: {snippet}\n\nRefactor code to mitigate the vulnerability (e.g., injection, hardcoded secrets). Follow OWASP and Java security best practices. Explain security improvement in comments."""

            return f"""SonarQube highlighted a maintainability issue in Java code.\nRule: {rule}\nMessage: {message}\nCode: {snippet}\n\nRefactor for readability, maintainability, and long-term reliability. Keep logic unchanged. Add comments where relevant."""

        if language == "python":
            if rule.startswith("python:S") or "naming" in message.lower():
                return f"""You are reviewing Python code flagged by SonarQube.\nRule: {rule}\nMessage: {message}\nContext: {snippet}\n\nFix the issue while preserving functionality and adhering to Pythonic best practices (PEP8, idiomatic code). Explain changes briefly in comments."""

            if "bug" in message.lower():
                return f"""You are reviewing a potential bug in Python code from SonarQube.\nRule: {rule}\nMessage: {message}\nCode: {snippet}\n\nFix the bug safely. Ensure functional correctness and add tests if needed. Explain the reason for the fix in comments."""

            if "vulnerability" in message.lower() or rule.startswith("security:"):
                return f"""You are a security expert. SonarQube flagged a vulnerability in Python code.\nRule: {rule}\nMessage: {message}\nCode: {snippet}\n\nRefactor code to mitigate the vulnerability (e.g., injection, hardcoded secrets). Follow OWASP and Python security best practices. Explain security improvement in comments."""

            return f"""SonarQube highlighted a maintainability issue in Python code.\nRule: {rule}\nMessage: {message}\nCode: {snippet}\n\nRefactor for readability, maintainability, and long-term reliability. Keep logic unchanged. Add comments where relevant."""

        # Default fallback for other languages
        return f"""SonarQube highlighted an issue.\nRule: {rule}\nMessage: {message}\nCode: {snippet}\n\nRefactor for readability, maintainability, and reliability. Keep logic unchanged. Add comments where relevant."""
