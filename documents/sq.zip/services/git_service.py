import os
import requests
from zipfile import Path
from git import Repo


class GitService:
    def __init__(self, repo_url, base_branch="main"):
        self.repo_dir = "/tmp"
        self.repo_url = repo_url
        self.base_branch = base_branch
        # self.new_branch_name = f"auto/sonarfix/{jira_id}"

    def clone_repo(self, jira_id):
        print("Cloning repo...")
        repo_dir = Path(self.repo_dir) / f"{jira_id}_repo"
        Repo.clone_from(self.repo_url, repo_dir)
        return repo_dir
    
    def create_feature_branch(self, jira_id):
        repo_dir = Path(self.repo_dir) / f"{jira_id}_repo"
        repo = Repo(repo_dir)
        branch_name = f"auto/sonarfix/{jira_id}"
        repo.git.checkout(self.base_branch)
        repo.git.pull("origin", self.base_branch)
        repo.git.checkout("-b", branch_name)
        return branch_name
    
    def commit_push(self, jira_id, issue_key):
        repo = Repo(self.repo_dir)
        branch_name = f"auto/sonarfix/{jira_id}"
        # If aider already committed, we may skip this. Else stage & commit
        if repo.is_dirty(untracked_files=True):
            repo.git.add("-A")
            msg = f"Auto-fix Sonar issue {issue_key} | jira:{jira_id} | model:aider+LLM"
            repo.index.commit(msg, author=repo.git.default_signature if False else (GIT_AUTHOR_NAME, GIT_AUTHOR_EMAIL))
        print("Pushing branch to origin...")
        origin = repo.remote(name="origin")
        origin.push(refspec=f"{branch_name}:{branch_name}")


    def create_pr(self, project_key, repo_slug, title, description, source_branch, dest_branch="main"):
        url = f"{BITBUCKET_API}/repositories/{project_key}/{repo_slug}/pullrequests"
        payload = {
            "title": title,
            "description": description,
            "source": {"branch": {"name": source_branch}},
            "destination": {"branch": {"name": dest_branch}},
            "close_source_branch": False
        }
        headers = {"Authorization": f"Bearer {BITBUCKET_TOKEN}", "Content-Type": "application/json"}
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        if response.status_code == 201:
            return response.json().get("links", {}).get("html", {}).get("href", "")
        else:
            return f"Failed to create PR: {response.text}"
        # return r.json()


    def clone_and_branch(self, jira_id):
        repo_dir = f"/tmp/{jira_id}_repo"
        branch_name = f"feature/{jira_id}"
        # Clone the repo
        os.system(f"git clone {self.repo_url} {repo_dir}")
        # Create and checkout new branch
        os.system(f"cd {repo_dir} && git checkout -b {branch_name}")
        return repo_dir

    def commit_and_push(self, jira_id):
        repo_dir = f"/tmp/{jira_id}_repo"
        branch_name = f"feature/{jira_id}"
        # Add all changes
        os.system(f"cd {repo_dir} && git add .")
        # Commit changes
        os.system(f"cd {repo_dir} && git commit -m 'Auto commit for {jira_id}'")
        # Push branch
        os.system(f"cd {repo_dir} && git push origin {branch_name}")

    def raise_pr(self, jira_id):
        branch_name = f"feature/{jira_id}"
        # Example Bitbucket API call (user must set BITBUCKET_TOKEN env var)
        bitbucket_url = "https://api.bitbucket.org/2.0/repositories/project/repo/pullrequests"
        headers = {
            "Authorization": f"Bearer {os.getenv('BITBUCKET_TOKEN')}",
            "Content-Type": "application/json"
        }
        data = {
            "title": f"Auto PR for {jira_id}",
            "source": {"branch": {"name": branch_name}},
            "destination": {"branch": {"name": "main"}},
            "description": f"Automated PR for {jira_id}",
            "close_source_branch": True
        }
        response = requests.post(bitbucket_url, headers=headers, json=data)
        if response.status_code == 201:
            return response.json().get("links", {}).get("html", {}).get("href", "")
        else:
            return f"Failed to create PR: {response.text}"
