class SonarQubeClient:
    def __init__(self, key):
        self.key = key

    def get_issues(self):
        # TODO: implement real SonarQube API call
        return [
            {"id": "1", "rule": "java:S100", "message": "Method names should comply with a naming convention."},
            {"id": "2", "rule": "java:S1854", "message": "Remove this unused assignment."},
        ]
