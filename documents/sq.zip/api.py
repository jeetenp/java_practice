from fastapi import FastAPI
from pydantic import BaseModel
from services.git_service import GitService
from services.sonarqube_client import SonarQubeClient
from services.aider_adapter import AiderAdapter

app = FastAPI()

class FixRequest(BaseModel):
    repo_url: str
    sonarqube_key: str
    jira_id: str

@app.post("/fix")
def fix_issues(req: FixRequest):
    git = GitService(req.repo_url)
    repo_path = git.clone_and_branch(req.jira_id)

    sonar = SonarQubeClient(req.sonarqube_key)
    issues = sonar.get_issues()

    aider = AiderAdapter(repo_path)
    for issue in issues:
        aider.fix_issue(issue)

    git.commit_and_push(req.jira_id)
    pr_url = git.raise_pr(req.jira_id)

    return {"status": "success", "pr_url": pr_url}
