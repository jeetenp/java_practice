import argparse
from services.git_service import GitService
from services.sonarqube_client import SonarQubeClient
from services.aider_adapter import AiderAdapter

def main():
    parser = argparse.ArgumentParser(description="SonarQube Issue Auto Fixer CLI", add_help=False)
    parser.add_argument("--config", type=str, help="Path to configuration.json")
    parser.add_argument("--repo-url", type=str, help="Git repository URL")
    parser.add_argument("--repo-clone-dir", type=str, default="I:/temp", help="Directory to clone the repo")
    parser.add_argument("--base-branch", type=str, default="develop", help="Base branch name")
    parser.add_argument("--sonarqube-key", type=str, help="SonarQube project key")
    parser.add_argument("--jira-id", type=str, help="JIRA ID")
    parser.add_argument("--help", action="store_true", help="Show help message and exit")
    args = parser.parse_args()

    if args.help:
        print("""
SonarQube Issue Auto Fixer CLI Usage:

Arguments:
  --config           Path to configuration.json (optional)
  --repo-url         Git repository URL
  --repo-clone-dir   Directory to clone the repo (default: I:/temp)
  --base-branch      Base branch name (default: develop)
  --sonarqube-key    SonarQube project key
  --jira-id          JIRA ID
  --help             Show this help message and exit

How to use:
  python cli.py --repo-url <URL> --sonarqube-key <KEY> --jira-id <ID>
  Optionally, use --config to provide a configuration file.
""")
        return

    if args.config:
        import json
        with open(args.config, "r") as f:
            config = json.load(f)
        repo_url = config["git"].get("repo_url", "")
        repo_clone_dir = config["git"].get("repo_clone_dir", "I:/temp")
        base_branch = config["git"].get("base_branch", "develop")
        sonarqube_key = config["sonarqube"].get("project_key", "")
        jira_id = config.get("jira_id", "")
    else:
        repo_url = args.repo_url or input("Enter git repo URL: ")
        repo_clone_dir = args.repo_clone_dir or input("Enter repo clone dir [I:/temp]: ") or "I:/temp"
        base_branch = args.base_branch or input("Enter base branch [develop]: ") or "develop"
        sonarqube_key = args.sonarqube_key or input("Enter SonarQube project key: ")
        jira_id = args.jira_id or input("Enter JIRA ID: ")

    git = GitService(repo_url, base_branch=base_branch)
    repo_path = git.clone_and_branch(jira_id)

    sonar = SonarQubeClient(sonarqube_key)
    issues = sonar.get_issues()

    aider = AiderAdapter(repo_path)
    for issue in issues:
        aider.fix_issue(issue)

    git.commit_and_push(jira_id)
    git.raise_pr(jira_id)

if __name__ == "__main__":
    main()
