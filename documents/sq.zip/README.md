# SonarQube Issue Auto Fixer

This project automatically fixes SonarQube issues using LLMs and Aider.

## Features
- Clone repo and create feature branch
- Fetch issues from SonarQube
- Auto-fix using Aider/LLM
- Commit, push, and raise PR in Bitbucket
- Link with Jira ticket

## Usage
### CLI
```bash
python cli.py --repo-url <url> --sonarqube-key <key> --jira-id <JIRA-123>
```

### API
```bash
uvicorn api:app --reload
```
